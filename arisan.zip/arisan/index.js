import readline from 'readline';
const peserta = [];

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function tambahPeserta() {
  rl.question('Masukkan nama peserta baru: ', (nama) => {
    peserta.push(nama);
    main();
  });
}

function tampilkanPeserta() {
  console.log(peserta);
  main();
}

function jalankanArisan() {
  if (peserta.length === 0) {
    console.log(
      'Belum ada peserta yang terdaftar, silahkan tambahkan peserta terlebih dahulu'
    );
    return main();
  }
  const pemenang = peserta[Math.floor(Math.random() * peserta.length)];
  console.log(`Pemenang arisan adalah ${pemenang}`);
  main();
}

function main() {
  console.log('Pilih menu:');
  console.log('1. Tambah Peserta');
  console.log('2. Tampilkan Daftar Peserta');
  console.log('3. Jalankan Arisan');
  console.log('4. Keluar');
  rl.question('Masukkan pilihan: ', (pilihan) => {
    switch (pilihan) {
      case '1':
        tambahPeserta();
        break;
      case '2':
        tampilkanPeserta();
        break;
      case '3':
        jalankanArisan();
        break;
      case '4':
        rl.close();
        break;
      default:
        console.log('Pilihan tidak valid');
        main();
    }
  });
}

main();
